package com.flowers.flowers_online;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowersOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
